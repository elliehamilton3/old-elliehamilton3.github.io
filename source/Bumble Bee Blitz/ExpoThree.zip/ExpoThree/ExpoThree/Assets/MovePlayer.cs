﻿using UnityEngine;
using System.Collections;

public class MovePlayer : MonoBehaviour {

	public float moveSpeed;

	Vector2 movement;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		if (Input.GetKey (KeyCode.UpArrow))
			transform.Translate (Vector2.up * moveSpeed * Time.deltaTime);
		if (Input.GetKey (KeyCode.DownArrow))
			transform.Translate (Vector2.down * moveSpeed * Time.deltaTime);

		if (Input.GetKey (KeyCode.LeftArrow)) {
			transform.Translate (Vector2.left * moveSpeed * Time.deltaTime);
		} else if (Input.GetKey (KeyCode.RightArrow)) {
			transform.Translate (Vector2.right * moveSpeed * Time.deltaTime);
		}

	}
}


# ExpoThree
Develop a game prototype that contains at least one of the following innovations: adaptive difficulty procedural generation of content use of a novel game interface (controller and/or display) real-world location-based elements

﻿using UnityEngine;
using System.Collections;

public class BeeAnimator : MonoBehaviour {

	// Animates the bee sprite

	public Sprite[] sprites;
	public float framesPerSecond;

	private SpriteRenderer spriteRenderer;

	GameController gameController;

	// Use this for initialization
	void Start () {
		gameController = GameObject.FindWithTag("GameController").GetComponent<GameController>();
		spriteRenderer = GetComponent<Renderer>() as SpriteRenderer;
	}
	
	// Update is called once per frame
	void Update () {
		int index = (int)(Time.timeSinceLevelLoad * framesPerSecond * gameController.colorSpeed);
		index = index % sprites.Length;
		spriteRenderer.sprite = sprites[ index ];
	
	}
}

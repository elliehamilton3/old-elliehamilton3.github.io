﻿using UnityEngine;
using System.Collections;

public class Controller : MonoBehaviour {

	public float xhex = 14.6f;
	public float yhex = 0.0f;
	public float zhex = 57.9f;

	Vector3 position;

	public HexGrid grid;
	public HexMesh hexMesh;

//	HexCell[] cells;

//	Color color = Color.blue;

	void Start() {
//		StartCoroutine(Example());
	}
//
//	IEnumerator Example() {
//		print(Time.time);
////		yield return new WaitForSeconds(5);
//		print(Time.time);
//
//
//
//		position = new Vector3 (xhex, yhex, zhex);
//
//		print ("The position used is: " + position);
//
//		position = transform.InverseTransformPoint(position);
//
//
//		print ("The position is now: " + position);
//
//		HexCoordinates coordinates = HexCoordinates.FromPosition(position);
//
//	
//		print ("The hex coordinates are: " + coordinates);
//
//		int index = coordinates.X + coordinates.Z * grid.width + coordinates.Z / 2;
//
//		print ("The index is: " + index);
//
//		HexCell cell = cells[index];
//
//		print ("The cell is: " + cell);
//
//		cell.color = color;
//		hexMesh.Triangulate(cells);
//
//
//	}

}
	
﻿using UnityEngine;
using System.Collections;
using System;

public class GameController : MonoBehaviour {

	public HexGrid hexGrid;

	public int[] colorMappings;

	public Color halfSpeedColor;
	public Color slowestSpeedColor;
	public Color doubleSpeedColor;
	public Color mixUpColor;
	public Color rowBehindColor;
	public Color defaultColor;
	public Color startEndColor;
	public Color circlePlayerColor;

	public float colorSpeed = 1.0f;

	public int cameraVelocity;

	void Start () {
		// Init array of cell and properties
		colorMappings = new int[hexGrid.width * hexGrid.height];

		// Set up grid colours on init
		// Loop array
		System.Random rnd = new System.Random();

		// Use random generator to decide cells types
		for(int i = 0; i < colorMappings.Length; i++) {
			int rand = rnd.Next (1, 30 + 1);
			colorMappings [i] = rand;

			if(rand == 10 || rand == 9) {
				hexGrid.ChangeColor (i, circlePlayerColor);
			}
			else if (rand == 11 || rand == 12 || rand == 13 || rand == 21 || rand == 22) {
				hexGrid.ChangeColor (i, halfSpeedColor);
			}
			else if (rand == 14 || rand == 15 || rand == 23 || rand == 24) {
				hexGrid.ChangeColor (i, slowestSpeedColor);
			}
			else if (rand == 16 || rand == 17 || rand == 18 || rand == 25 || rand == 26) {
				hexGrid.ChangeColor (i, doubleSpeedColor);
			}
			else if (rand == 19 || rand == 27) {
				hexGrid.ChangeColor (i, mixUpColor);
			}
			else if (rand == 20) {
				hexGrid.ChangeColor (i, rowBehindColor);		
			}
		}


		// Set first few columns as white to start
		// End ones as white to start
		for(int i = 0; i < hexGrid.height; i++){
			hexGrid.ChangeColor (i * hexGrid.width, startEndColor);
			SetColorMapIndex (i * hexGrid.width, 1);
		}
		for(int i = 0; i < hexGrid.height; i++){
			hexGrid.ChangeColor ((i * hexGrid.width)+1, startEndColor);
			SetColorMapIndex ((i * hexGrid.width)+1, 1);
		}
		for(int i = 1; i < hexGrid.height+1; i++){
			hexGrid.ChangeColor ((i * hexGrid.width)-1, startEndColor);
			SetColorMapIndex ((i * hexGrid.width)-1, 1);
		}
		for(int i = 1; i < hexGrid.height+1; i++){
			hexGrid.ChangeColor ((i * hexGrid.width)-2, startEndColor);
			SetColorMapIndex ((i * hexGrid.width)-2, 1);
		}
		for(int i = 1; i < hexGrid.height+1; i++){
			hexGrid.ChangeColor ((i * hexGrid.width)-3, startEndColor);
			SetColorMapIndex ((i * hexGrid.width)-3, 1);
		}
		for(int i = 1; i < hexGrid.height+1; i++){
			hexGrid.ChangeColor ((i * hexGrid.width)-4, startEndColor);
			SetColorMapIndex ((i * hexGrid.width)-4, 1);
		}
		for(int i = 1; i < hexGrid.height+1; i++){
			hexGrid.ChangeColor ((i * hexGrid.width)-5, startEndColor);
			SetColorMapIndex ((i * hexGrid.width)-5, 1);
		}
		for(int i = 1; i < hexGrid.height+1; i++){
			hexGrid.ChangeColor ((i * hexGrid.width)-6, startEndColor);
			SetColorMapIndex ((i * hexGrid.width)-6, 1);
		}
	}


	void Update(){
		Camera.main.GetComponent<MoveCamera> ().moveSpeed += cameraVelocity * 0.1f * Time.deltaTime;
	}

	// Set the type of cell from an index
	public void SetColorMapIndex(int index, int color){
		colorMappings [index] = color;
	}
	public void SetColorMapIndex(HexCell cell, int color){
		colorMappings [cell.index] = color;
	}


	// End of game code
	// Stops camera moving
	public void EndGame(){
		Camera.main.GetComponent<MoveCamera>().moveSpeed = 0;
		cameraVelocity = 0;
	}
}
﻿using UnityEngine;

public class GameOverScript : MonoBehaviour
{
	// This adds the GUI elements to the screen to show the game is over.

	GameObject frontPlayer;
	Rect textArea = new Rect(Screen.width / 2 - (240 / 2),Screen.height/2-50,240,100);


	// Check which player is in front (by x postion) and determines winner
	void WinnerCheck(){
		GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
		players[0].GetComponent<MovePlayer>().moveSpeed = 0f;
		players[1].GetComponent<MovePlayer>().moveSpeed = 0f;


		if (players [0].transform.position.x > players [1].transform.position.x)
			frontPlayer = players [0];
		else
			frontPlayer = players [1];
	}

	void OnGUI()
	{
		GUIStyle style = new GUIStyle();
		style.fontSize = 80;
		style.normal.textColor = Color.white;
		style.alignment = TextAnchor.MiddleCenter;
		WinnerCheck ();
		const int buttonWidth = 240;
		const int buttonHeight = 100;

		Font myFont = (Font)Resources.Load("Bumblebee", typeof(Font));
		style.font = myFont;

		frontPlayer.transform.localScale = new Vector3(5f, 5f, 0f);
		GUI.Label(textArea,"Winner", style);


		GUIStyle buttonStyle = new GUIStyle(GUI.skin.button);
		buttonStyle.fontSize = 30;
		buttonStyle.font = myFont;


		if (
			GUI.Button(
				// Center in X, 1/3 of the height in Y
				new Rect(
					Screen.width / 2 - (buttonWidth / 2),
					(1 * Screen.height / 3) - (buttonHeight / 2),
					buttonWidth,
					buttonHeight
				),
				"Replay", buttonStyle
			)
		)
		{
			// Reload the level
			Application.LoadLevel("Scene");
		}

		if (
			GUI.Button(
				// Center in X, 2/3 of the height in Y
				new Rect(
					Screen.width / 2 - (buttonWidth / 2),
					(2 * Screen.height / 3) - (buttonHeight / 2),
					buttonWidth,
					buttonHeight
				),
				"Back to main menu", buttonStyle
			)
		)
		{
			// Reload the level
			Application.LoadLevel("Menu");
		}
	}
}
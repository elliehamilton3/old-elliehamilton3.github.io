﻿using UnityEngine;
using System.Collections;

public class HexCell : MonoBehaviour {

	public HexCoordinates coordinates;
	GameController gameController;

	public Color color;

	public int index;

	[SerializeField]
	HexCell[] neighbors;

	// neighbours follow compass directions, see other hex files

	public HexCell GetNeighbor (HexDirection direction) {
		return neighbors[(int)direction];
	}
		
	public void SetNeighbor (HexDirection direction, HexCell cell) {
		neighbors[(int)direction] = cell;
		cell.neighbors[(int)direction.Opposite()] = this;
	}
		
	// Runs when cell becomes visible
	// When last cells become visible, stop camera moving left
	void OnBecameVisible() {
		if (GetNeighbor (HexDirection.E) == null) {
			StartCoroutine (StopCamera());
		}
	}

	IEnumerator StopCamera() {
		yield return new WaitForSeconds(4);
		gameController = GameObject.FindWithTag("GameController").GetComponent<GameController>();
		gameController.EndGame ();
	}
}
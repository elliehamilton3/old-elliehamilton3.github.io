﻿using UnityEngine;
using System.Collections;

public class HexCellInner : MonoBehaviour {

	public HexCoordinates coordinates;

	public Color color;

	// Runs when cell becomes visible
	void OnBecameVisible() {
		print (coordinates + " is here.");
	}


	// Destroys cell when it leaves screen
	void OnBecameInvisible() {
		Destroy(gameObject);
		print (coordinates + " is destroyed.");
	}
}

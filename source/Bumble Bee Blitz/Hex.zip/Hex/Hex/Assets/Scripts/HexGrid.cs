﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections.Generic;

public class HexGrid : MonoBehaviour {

	GameController gameController;

	public int width = 6;
	public int height = 6;

	public Color defaultColor = Color.white;

	public HexCell cellPrefab;
	public Text cellLabelPrefab;

	HexCell[] cells;

	Canvas gridCanvas;
	HexMesh hexMesh;

	void Awake () {
		gridCanvas = GetComponentInChildren<Canvas>();
		hexMesh = GetComponentInChildren<HexMesh>();

		cells = new HexCell[height * width];

		for (int z = 0, i = 0; z < height; z++) {
			for (int x = 0; x < width; x++) {
				CreateCell(x, z, i++);
			}
		}
	}

	void Start () {
		gameController = GameObject.FindWithTag("GameController").GetComponent<GameController>();
		hexMesh.Triangulate(cells);
	}

	public void ColorCell (Vector3 position, Color color) {
		position = transform.InverseTransformPoint(position);
		HexCoordinates coordinates = HexCoordinates.FromPosition(position);
		int index = coordinates.X + coordinates.Z * width + coordinates.Z / 2;
		HexCell cell = cells[index];
		cell.color = color;
		hexMesh.Triangulate(cells);
	}

	public int GetIndex(Vector3 position) {
		position = transform.InverseTransformPoint(position);
		HexCoordinates coordinates = HexCoordinates.FromPosition(position);
		int index = coordinates.X + coordinates.Z * width + coordinates.Z / 2;

		return index;
	}

	public HexCell GetCell(int index){
		HexCell cell = cells[index];

		return cell;
	}

	public void ChangeColor(HexCell cell, Color color){
		cell.color = color;
		hexMesh.Triangulate(cells);
	}

	public void ChangeColor(int index, Color color){
		HexCell cell = cells[index];

		cell.color = color;
		hexMesh.Triangulate(cells);
	}
		
	void CreateCell (int x, int z, int i) {
		Vector3 position;
		position.x = (x + z * 0.5f - z / 2) * (HexMetrics.innerRadius * 2f);
		position.y = 0f;
		position.z = z * (HexMetrics.outerRadius * 1.5f);

		HexCell cell = cells[i] = Instantiate<HexCell>(cellPrefab);
		cell.transform.SetParent(transform, false);
		cell.transform.localPosition = position;
		cell.coordinates = HexCoordinates.FromOffsetCoordinates(x, z);
		cell.color = defaultColor;
		cell.index = i;

		if (x > 0) {
			cell.SetNeighbor(HexDirection.W, cells[i - 1]);
		}
		if (z > 0) {
			if ((z & 1) == 0) {
				cell.SetNeighbor(HexDirection.SE, cells[i - width]);
				if (x > 0) {
					cell.SetNeighbor(HexDirection.SW, cells[i - width - 1]);
				}
			}
			else {
				cell.SetNeighbor(HexDirection.SW, cells[i - width]);
				if (x < width - 1) {
					cell.SetNeighbor(HexDirection.SE, cells[i - width + 1]);
				}
			}
		}

		Text label = Instantiate<Text>(cellLabelPrefab);
		label.rectTransform.SetParent(gridCanvas.transform, false);
		label.rectTransform.anchoredPosition = new Vector2(position.x, position.z);
	}


	// Special cell methods

	// This cells turns the column behind it all to the slowest cell type.
	public void ColumnBehind(int index){
		int indent = index - (((int)Math.Floor ((double)index / (double)width)) * width) - 1;

		// Change colour and then set the mapping to a slower int (14)
		for(int i = 0; i < height; i++){
			ChangeColor ((indent) + (i * width), gameController.slowestSpeedColor);
			gameController.SetColorMapIndex (indent + (i * width), 14);
		}
	}

	// This cell clears a path in front of you
	public void RowInFront(int index){
		// Change colour and then set the mapping 
		for(int i = 1; i < 7; i++){
			if(i%3 == 0){
				ChangeColor (index+i, gameController.doubleSpeedColor);
				gameController.SetColorMapIndex (index+i, 16);
			}
			else{
				ChangeColor (index+i, gameController.defaultColor);
				gameController.SetColorMapIndex (index+i, 1);
			}
		}
	}

	// This cells puts a ring of slow cells around the player in front
	public void CirclePlayer(){

		// Get players into array
		GameObject[] players = GameObject.FindGameObjectsWithTag("Player");

		GameObject frontPlayer;

		// Check which player is in front by x position.
		if (players [0].transform.position.x > players [1].transform.position.x)
			frontPlayer = players [0];
		else
			frontPlayer = players [1];

		int index = GetIndex (frontPlayer.transform.position);
		HexCell cell = GetCell (index);

		// Check if the surrounding neighbours exist, if so then colour them
		if (cell.GetNeighbor (HexDirection.NE) != null) {
			ChangeColor (cell.GetNeighbor (HexDirection.NE), gameController.slowestSpeedColor);
			gameController.SetColorMapIndex (cell.GetNeighbor (HexDirection.NE), 14);
		}

		if (cell.GetNeighbor (HexDirection.E) != null) {
			ChangeColor (cell.GetNeighbor (HexDirection.E), gameController.slowestSpeedColor);
			gameController.SetColorMapIndex (cell.GetNeighbor(HexDirection.E), 14);
		}

		if (cell.GetNeighbor (HexDirection.SE) != null) {
			ChangeColor (cell.GetNeighbor (HexDirection.SE), gameController.slowestSpeedColor);
			gameController.SetColorMapIndex (cell.GetNeighbor (HexDirection.SE), 14);
		}

		if (cell.GetNeighbor (HexDirection.SW) != null) {
			ChangeColor (cell.GetNeighbor (HexDirection.SW), gameController.slowestSpeedColor);
			gameController.SetColorMapIndex (cell.GetNeighbor (HexDirection.SW), 14);
		}

		if (cell.GetNeighbor (HexDirection.W) != null) {
			ChangeColor (cell.GetNeighbor (HexDirection.W), gameController.slowestSpeedColor);
			gameController.SetColorMapIndex (cell.GetNeighbor (HexDirection.W), 14);
		}

		if (cell.GetNeighbor (HexDirection.NW) != null) {
			ChangeColor (cell.GetNeighbor (HexDirection.NW), gameController.slowestSpeedColor);
			gameController.SetColorMapIndex (cell.GetNeighbor (HexDirection.NW), 14);
		}
	}		
}
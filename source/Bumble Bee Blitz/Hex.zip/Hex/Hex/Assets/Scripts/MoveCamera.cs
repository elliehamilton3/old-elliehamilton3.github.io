﻿using UnityEngine;
using System.Collections;

public class MoveCamera : MonoBehaviour {

	public float moveSpeed;

	private Vector3 newPosition;

	bool ready = false;

	// Use this to delay camera moving on start
	void Start () {
		StartCoroutine (WaitForStart());
	}

	IEnumerator WaitForStart(){
		yield return new WaitForSeconds (1f);
		newPosition = transform.position;
		ready = true;
	}
	
	// Update is called once per frame
	void Update () {
		if (ready) {
			newPosition.x += Time.deltaTime * moveSpeed;
			transform.position = newPosition;
		}
	}
}

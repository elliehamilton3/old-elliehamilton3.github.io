﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MovePlayer : MonoBehaviour {

	GameController gameController;

	public float moveSpeed;
	Vector2 movement;

	public HexGrid hexgrid;

	public int playerNo;

	void Start () {
		gameController = GameObject.FindWithTag("GameController").GetComponent<GameController>();
	}
	
	void Update () {

		// Get the player's location, the index and the the Cell object
		Vector3 position = transform.position;
		int index = hexgrid.GetIndex (position);


		// Check if the bee is over a different colour
		// Update speed as required	// Update cells if power-up

		int cellType;

		if (index < 0 || index > (hexgrid.width * hexgrid.height)) {
			cellType = 0;
		} 
		else {			
			cellType = gameController.colorMappings [index];
		}

		if (cellType == 0) {
			gameController.colorSpeed = 0.1f;
		}

		else if(cellType == 10 || cellType == 9) {
			gameController.colorSpeed = 1.0f;
			hexgrid.CirclePlayer ();
		}

		else if (cellType == 11 || cellType == 12 || cellType == 13 || cellType == 21 || cellType == 22) {
			// Half speed
			gameController.colorSpeed = 0.5f;
		}

		else if (cellType == 14 || cellType == 15 || cellType == 23 || cellType == 24) {
			// Slowest speed
			gameController.colorSpeed = 0.25f;
		}

		else if (cellType == 16 || cellType == 17 || cellType == 18 || cellType == 25 || cellType == 26) {
			// Double speed
			gameController.colorSpeed = 2.0f;
		}

		else if (cellType == 19 || cellType == 27) {
			// Row in front
			hexgrid.RowInFront (index);
			gameController.colorSpeed = 1.0f; 
		}

		else if (cellType == 20) {
			// Column behind
			gameController.colorSpeed = 1.0f;
			hexgrid.ColumnBehind (index);
		} 

		else {
			// Default
			gameController.colorSpeed = 1.0f;
		}


		// Movement controls

		if ((Input.GetKey (KeyCode.UpArrow) && playerNo == 1) || (Input.GetKey(KeyCode.W) && playerNo == 2)) {
			transform.Translate (Vector2.up * moveSpeed * gameController.colorSpeed * Time.deltaTime);
		}
		if ((Input.GetKey (KeyCode.DownArrow) && playerNo == 1) || (Input.GetKey(KeyCode.S) && playerNo == 2)) {
			transform.Translate (Vector2.down * moveSpeed * gameController.colorSpeed * Time.deltaTime);
		}
		if ((Input.GetKey (KeyCode.LeftArrow) && playerNo == 1) || (Input.GetKey(KeyCode.A) && playerNo == 2)) {
			transform.Translate (Vector2.left * moveSpeed * gameController.colorSpeed * Time.deltaTime);
		} 
		if ((Input.GetKey (KeyCode.RightArrow) && playerNo == 1) || (Input.GetKey(KeyCode.D) && playerNo == 2)) {
			transform.Translate (Vector2.right * moveSpeed * gameController.colorSpeed * Time.deltaTime);
		}

		// When player gets to end, call end game
		if(index%(hexgrid.width-1) == 0){
			transform.gameObject.AddComponent<GameOverScript>();
		}

	}

	// If player leaves the screen, end game
	void OnBecameInvisible(){
		gameController.EndGame ();
		transform.gameObject.AddComponent<GameOverScript>();
	}
}
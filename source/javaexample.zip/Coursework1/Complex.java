import java.text.DecimalFormat;

public class Complex {
	private double realNum;
	private double imagNum;
	//the real and imaginary parts of the complex number are stored as private doubles
	public Complex(double real, double imag){
		this.realNum = real;
		this.imagNum = imag;
	}
	//the constructor has two parameters one double for the real part of the complex number and one for the imaginary part
	public double getReal(){
		return realNum;
	}
	//accessor method for the real part of the complex number
	public double getImag(){
		return imagNum;
	}
	//accessor method for the imaginary part of the complex number
	public Complex square(){
		double s1 = realNum * realNum;
		double s2 = (realNum * imagNum) * 2;
		double s3 = (imagNum * imagNum) * -1;;
		return new Complex((s1 + s3), s2);
	}	
	//method that squares the complex number that it is called on
	public int modulus(){
		double mSq = (realNum * realNum) + (imagNum * imagNum);
		return (int)Math.round(Math.sqrt(mSq));
	}
	//method that returns the modulus of the complex number that it is called on
	public Complex add(Complex d){
		double newReal = d.getReal() + realNum;
		double newImag = d.getImag() + imagNum;
		return new Complex(newReal, newImag);	
	}
	//adds the complex number taken in as a parameter to the complex number that it is called on
	public Complex conjugate(){
		double imag = getImag()*-1;
		return new Complex(getReal(), imag);
	}
	//returns the conjugate of the complex number that it is called on - used for the tricorn fractal
	public String toString(){
		DecimalFormat df = new DecimalFormat("#.##");
		return df.format(realNum) + " + " + df.format(imagNum) + "i";
	}
	//returns a string of the complex number to two decimal places
}
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;


@SuppressWarnings("serial")
public class FractalGUI extends JPanel{
	private double panelHeight, panelWidth;
	private double realTop = 2, realBottom = -2, imagTop = 1.6, imagBottom = -1.6;
	//stores its own panel height and width and real and imaginary top and bottom of the axis 
	//these can then be changed independently of the mandelbrot axis and some of the other fractals override them
	Complex userSelected = new Complex(-0.55, -0.55);
	//it is initialised with a complex number of -0.5, -0.5
	private MandelBrotGUI mbg;
	//stores a reference to the mandelbrot gui it is connected to
	private int fractal = 0;
	//this int is used to set the fractal on display, default set to julia set
	
	public FractalGUI(MandelBrotGUI mbg){
		this.mbg = mbg;
		setSize(500, 500);
		Dimension d = getSize();
		panelWidth = d.getWidth();
		panelHeight = d.getHeight();
	}
	//the constructor stores a reference to the mandelbrot gui passed in as a parameter
	//it also sets the size of the panel and the panel width and height
	public void setFractal(String s){
		if(s.equals("JuliaSet")){
			fractal = 0;
		}
		else if(s.equals("BurningShip")){
			fractal = 1;
		}
		else if(s.equals("Tricorn")){
			fractal = 2;
		}
	}
	/*the set fractal method is used to set which fractal will be displayed in the left hand panel
	*it takes in a string which is passed from the selected item in the jcombobox
	*it sets the fractal int used in the paint method
	*/
	public boolean isJulia(){
		if(fractal == 0){
			return true;
		}
		else{
			return false;
		}
	}
	//this method just returns true or false depending on whether the current fractal being displayed is the julia set
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		panelWidth = getWidth();
		panelHeight = getHeight();
		if(fractal==0){
			visualiseJSet(g);
		}
		else if(fractal == 1){
			visualiseBSet(g);
		}
		else if (fractal == 2){
			visualiseTSet(g);
		}
	}
	/*the paint method calls super paint method and checks to see which fractal it should display
	*can be easily expanded to add more fractal code just needs to be added for the fractal calculation/visualisation
	*the arraylist used for the combo box on screen would need to be updated and the set fractal method and that is all
	*/
	public void updateSet(Complex userSelected){
		this.userSelected = userSelected;
		repaint();
	}
	//this method updates the userSelected point for the julia set and calls repaint
	public Complex toComplexNum(int x, int y){
		double xInc = (realTop-realBottom)/panelWidth;
		double yInc = (imagTop-imagBottom)/panelHeight;
		double r = (x*xInc) + realBottom;
		double i = imagTop - (y*yInc);
		return new Complex(r, i);		
	}
	//this method turns x and y coordinates to a complex number which it returns
	public void visualiseJSet(Graphics g){
		realTop = 2;
		realBottom = -2;
		imagTop = 1.6;
		imagBottom = -1.6;
		for(int y = 0; y <= panelHeight; y++){
			for(int x = 0; x <= panelWidth; x++){
				Complex c = toComplexNum(x, y);
				Complex c2 = c;
				for(int i = 1; i < mbg.iterate; i++){
					c2 = (c2.square()).add(userSelected);
					if(c2.modulus() < 2){
						g.setColor(Color.BLACK);
					}
					else if(c2.modulus() > 2){
						if(i<=5){
							Color col = new Color(150, 255-(i*40), 255);
							g.setColor(col);
							i=mbg.iterate;
						}
						else if(i<=10){
							Color col = new Color(0, 255-(i*20), 255);
							g.setColor(col);
							i=mbg.iterate;
						}
						else if (i<=30){
							Color col = new Color(0, 255-(i*6), 255);
							g.setColor(col);
							i=mbg.iterate;
						}
						else{
							Color col = new Color(0, 0, 0);
							g.setColor(col);
							i=mbg.iterate;
						}
						
					}
					g.fillRect(x, y, 1, 1);
				}
			}
		}
	}
	/*this is the method which calculates and visualises the julia set, it sets the real and imaginary axis values first
	 * it loops through pixel by pixel and does the julia set calculation (using the user selected point) to see if or when it diverges
	 * it uses this iterations value to set the colour to plot the pixel
	 */
	public void visualiseBSet(Graphics g){
		realTop = 2.5;
		realBottom = -2.5;
		imagTop = 2;
		imagBottom = -2;
		for(int y = 0; y <= panelHeight; y++){
			for(int x = 0; x <= panelWidth; x++){
				Complex c = toComplexNum(x, y);
				Complex c2 = c;
				for(int i = 1; i < mbg.iterate; i++){
					c2 = new Complex(Math.abs(c2.getReal()), -1*Math.abs(c2.getImag()));
					c2 = (c2.square()).add(c);
					if(c2.modulus() < 2){
						g.setColor(Color.BLACK);
					}
					else if(c2.modulus() > 2){
						if(i<=20){
							Color col = new Color(150, 255-(i*8), 255-(i));
							g.setColor(col);
							i=mbg.iterate;
						}
						else if(i<=50){
							Color col = new Color(0, 255-(i*4), 255-(i));
							g.setColor(col);
							i=mbg.iterate;
						}
						else if (i<=100){
							Color col = new Color(0, 255-(i*2), 255-(i));
							g.setColor(col);
							i=mbg.iterate;
						}
						else{
							Color col = new Color(0, 0, 0);
							g.setColor(col);
							i=mbg.iterate;
						}
						
					}
					g.fillRect(x, y, 1, 1);
				}
			}
		}
	}
	/*this is the method which calculates and visualises the burning ship set, it sets the real and imaginary axis values first
	 * it loops through pixel by pixel and does the burning ship calculation to see if or when it diverges
	 * it uses this iterations value to set the colour to plot the pixel
	 */
	public void visualiseTSet(Graphics g){
		realTop = 2.5;
		realBottom = -2.5;
		imagTop = 2.5;
		imagBottom = -2.5;
		for(int y = 0; y <= panelHeight; y++){
			for(int x = 0; x <= panelWidth; x++){
				Complex c = toComplexNum(x, y);
				Complex c2 = c;
				for(int i = 1; i < mbg.iterate; i++){
					c2 = ((c2.square()).conjugate()).add(c);
					if(c2.modulus() < 2){
						g.setColor(Color.BLACK);
					}
					else if(c2.modulus() > 2){
						if(i<=5){
							Color col = new Color(150, 255-(i*40), 255);
							g.setColor(col);
							i=mbg.iterate;
						}
						else if(i<=10){
							Color col = new Color(0, 255-(i*20), 255);
							g.setColor(col);
							i=mbg.iterate;
						}
						else if (i<=30){
							Color col = new Color(0, 255-(i*6), 255);
							g.setColor(col);
							i=mbg.iterate;
						}
						else{
							Color col = new Color(0, 0, 0);
							g.setColor(col);
							i=mbg.iterate;
						}
						
					}
					g.fillRect(x, y, 1, 1);
				}
			}
		}
	}
}
/*this is the method which calculates and visualises the tricorn set, it sets the real and imaginary axis values first
 * it loops through pixel by pixel and does the tricorn set calculation to see if or when it diverges
 * it uses this iterations value to set the colour to plot the pixel
 */
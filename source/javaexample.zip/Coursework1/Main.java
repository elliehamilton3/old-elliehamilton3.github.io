import java.awt.*;
import java.awt.event.*;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Main {
	public static void main(String[] args) {
		MandelBrotGUI mbg = new MandelBrotGUI();
		mbg.init();
		MandelBrotFrame mbf = new MandelBrotFrame(mbg, "MandelBrot GUI");
		mbf.init();
	}
}
//the main class just constructs a mandelbrot gui and mandelbrot frame and calls the init method which sets the size etc
@SuppressWarnings("serial")
class MandelBrotFrame extends JFrame{
	private MandelBrotGUI mbg;
	private JTextField realT, realB, imagT, imagB, num;
	private JComboBox fracs;
	private JButton toggle;
	private JComboBox favs;
	private JComboBox traps;
	//references to some of the components that need to be accessed by the listeners
	private ArrayList<Complex> jSetFav = new ArrayList<Complex>();
	//an arraylist which is constructed with the frame and is used to store a list of all the favourites, a new one is created each time a new frame is created
	public MandelBrotFrame(MandelBrotGUI mbg, String title){
		super(title);
		this.mbg = mbg;
	}
	//the constructor takes a mandelbrot gui and stores it and sets the title of the frame
	public void init(){
		this.setSize(1020, 630);
		this.setMinimumSize(new Dimension(1020, 630));
		this.setLayout(new BorderLayout());
		//sets the size and layout for the frame
		
		JPanel p = new JPanel();
		p.setSize(500, 100);
		//creates a new panel to add the buttons etc to
		
		JTextField cp = new JTextField("Complex point:");
		cp.setEditable(false);
		mbg.clickTF = new JTextField(mbg.frac.userSelected.toString());
		mbg.clickTF.setEditable(false);
		JPanel jp0 = new JPanel();
		jp0.add(cp);
		jp0.add(mbg.clickTF);
		//text field for the user selected complex number
		
		JPanel jp1 = new JPanel();
		JTextField realAxis = new JTextField("Real Axis:  -");
		realAxis.setEditable(false);
		realB = new JTextField(String.valueOf(mbg.realBottom*-1));
		realB.addActionListener(new TextListener("realBottom", realB));
		JTextField to = new JTextField(" to ");
		to.setEditable(false);
		realT = new JTextField(String.valueOf(mbg.realTop));
		realT.addActionListener(new TextListener("realTop", realT));
		jp1.add(realAxis);
		jp1.add(realB);
		jp1.add(to);
		jp1.add(realT);
		//the real axis text fields
		
		JPanel jp2 = new JPanel();
		JTextField imagAxis = new JTextField("Imaginary Axis:  -");
		imagAxis.setEditable(false);
		imagB = new JTextField(String.valueOf(mbg.imagBottom*-1));
		imagB.addActionListener(new TextListener("imagBottom", imagB));
		JTextField to1 = new JTextField(" to ");
		to1.setEditable(false);
		imagT = new JTextField(String.valueOf(mbg.imagTop));
		imagT.addActionListener(new TextListener("imagTop", imagT));
		jp2.add(imagAxis);
		jp2.add(imagB);
		jp2.add(to1);
		jp2.add(imagT);
		//the imaginary axis text fields
		
		JPanel jp3 = new JPanel();
		JTextField itera = new JTextField("Iterations: ");
		itera.setEditable(false);
		num = new JTextField("100");
		num.addActionListener(new TextListener("iterate", num));
		jp3.add(itera);
		jp3.add(num);
		//the iterations text fields	
		
		JButton reset = new JButton("Reset MandelBrot");
		reset.addActionListener(new ResetListener());
		//the reset button		
		
		JButton fav = new JButton("Add to Favourites");
		fav.addActionListener(new FavAddListener());
		//the favourite button		
		
		JButton save = new JButton("Save Right Panel Image");
		save.addActionListener(new SaveListener(this));
		//the save right panel image button		
		
		toggle = new JButton("Turn Julia Set Live Updates Off");
		toggle.addActionListener(new ToggleListener());
		//the toggle live updates button	
		
		JTextField showFav = new JTextField("Favourites:");
		showFav.setEditable(false);	
		favs = new JComboBox();
		favs.addItemListener(new FavListener());
		JPanel jp4 = new JPanel();
		jp4.setLayout(new GridLayout(1, 2));
		jp4.add(showFav);
		jp4.add(favs);
		//the favourites text field and combobox in a panel
		
		JTextField fracList = new JTextField("Fractal:");
		fracList.setEditable(false);	
		fracs = new JComboBox();
		addFractalList();
		fracs.addItemListener(new FractalListener());
		JPanel jp5 = new JPanel();
		jp5.setLayout(new GridLayout(1, 2));
		jp5.add(fracList);
		jp5.add(fracs);
		//the fractal display textfield and combo box
		
		JTextField orbitTraps = new JTextField("MandelBrot Orbit Traps:");
		orbitTraps.setEditable(false);	
		traps = new JComboBox();
		addTrapList();
		traps.addItemListener(new TrapListener());
		//the orbit traps text field and combo box
		
		p.setLayout(new GridLayout(3, 4));
		p.add(jp1);
		p.add(jp2);
		p.add(jp3);
		p.add(jp0);
		p.add(reset);
		p.add(fav);
		p.add(save);
		p.add(toggle);
		p.add(jp4);
		p.add(jp5);
		p.add(orbitTraps);
		p.add(traps);
		//adding all the buttons etc to the jpanel

		this.add(p, BorderLayout.NORTH);
		JPanel m = new JPanel();
		m.setLayout(new GridLayout(1, 2));
		m.add(mbg);
		m.add(mbg.frac);		
		this.add(m, BorderLayout.CENTER);
		//adding the mandelbrot and other fractal diaplay
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void paintComponent(Graphics g){
		super.paint(g);
	}
	//calls the super paint method
	public void addFractalList(){
		ArrayList<String> fr = new ArrayList<String>();
		fr.add(new String("JuliaSet"));
		fr.add(new String("BurningShip"));
		fr.add(new String("Tricorn"));
		for (int i = 0; i < fr.size(); i++){
			fracs.addItem(fr.get(i));
		}
	}
	//the method which creates arraylist which stores the fractal types and adds them to the combo box
	public void addTrapList(){
		ArrayList<String> tr = new ArrayList<String>();
		tr.add(new String("Normal"));
		tr.add(new String("Orbit Trap A"));
		tr.add(new String("Orbit Trap B"));
		tr.add(new String("Orbit Trap C"));
		tr.add(new String("Orbit Trap D"));
		for (int i = 0; i < tr.size(); i++){
			traps.addItem(tr.get(i));
		}
	}
	//the method which creates arraylist which stores the orbit traps and adds them to the combo box
	class FavListener implements ItemListener{
		public void itemStateChanged(ItemEvent itemEvent) {
			if(itemEvent.getStateChange() == ItemEvent.SELECTED){
				mbg.frac.updateSet(mbg.fromString((itemEvent.getItem()).toString()));
			}
		}
	}
	//is the listener attached to the favourites combo box and calls the update set method passing the string of the selected item
	class FavAddListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			if(mbg.frac.isJulia()){
				jSetFav.add(mbg.frac.userSelected);
				favs.removeAllItems();
				for (int i = 0; i < jSetFav.size()&&i<10 ; i++){
					favs.addItem(jSetFav.get(jSetFav.size()-1-i));
				}
			}
		}
	}
	//if the julia set is displaying them this method adds the user selected point at the time of the button click to the arraylist of favourites
	class SaveListener implements ActionListener{
		MandelBrotFrame mbf;
		public SaveListener(MandelBrotFrame mbf){
			this.mbf = mbf;
		}
		public void actionPerformed(ActionEvent e){
			JFileChooser chooser = new JFileChooser();
			FileFilter filter = new FileNameExtensionFilter("PNG Images", "png");
			chooser.setFileFilter(filter);
			chooser.setAcceptAllFileFilterUsed(false);
			if(chooser.showSaveDialog(mbf) == JFileChooser.APPROVE_OPTION){
				File f = chooser.getSelectedFile();
				try{		
					RenderedImage rImage = (RenderedImage)mbg.getScreenShot(mbg.frac);
					ImageIO.write(rImage, "png", f);
				}
				catch(IOException err){
					JOptionPane.showMessageDialog(mbf, err.getMessage(),"Cannot Save Image",JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}
	//this method renders the image on the right hand panel and brings up a save dialog and allows the user to save that image to a file of their choice
	class ToggleListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
	    	if(mbg.updatesOn){
	    		mbg.updatesOn = false;
	    		toggle.setText("Turn Julia Set Live Updates On");
	    	}
	    	else{
	    		mbg.updatesOn = true;
	    		toggle.setText("Turn Julia Set Live Updates Off");
	    	}
		}
		
	}
	//this listener is attached to the button and toggles the live julia set updates on and off
	class ResetListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			mbg.realTop = 2.0;
			realT.setText("2.0");
			mbg.realBottom = -2.0;
			realB.setText("2.0");
			mbg.imagTop = 1.6;
			imagT.setText("1.6");
			mbg.imagBottom = -1.6;
			imagB.setText("1.6");
			mbg.iterate = 100;
			num.setText("100");
			mbg.trapType = 0;
			traps.setSelectedIndex(0);
			repaint();
		}
	}
	//this resets the mandelbrot to its original fields for the axis, iteration and to the normal mandelbrot display with no orbit traps
	class FractalListener implements ItemListener{	
		public void itemStateChanged(ItemEvent itemEvent) {
			if(itemEvent.getStateChange() == ItemEvent.SELECTED){
				mbg.frac.setFractal((itemEvent.getItem()).toString());
				repaint();
			}
		}
	}
	//is the listener attached to the fractal combo box and calls the set fractal method passing the string of the selected item
	class TrapListener implements ItemListener{
		public void itemStateChanged(ItemEvent itemEvent) {
			if(itemEvent.getStateChange() == ItemEvent.SELECTED){
				mbg.setTrap((itemEvent.getItem()).toString());
				repaint();
			}
		}
	}
	//is the listener attached to the orbit trap combo box and calls the set trap method passing the string of the selected item
	class TextListener implements ActionListener{
		String s;
		private JTextField tf;
		public TextListener(String s, JTextField tf){
			this.s = s;
			this.tf = tf;
		}
		public void actionPerformed(ActionEvent e){
			if(isNumeric(tf.getText())&&Double.parseDouble(tf.getText())>0){
				if(s.equals("realTop")){
					mbg.realTop = Double.parseDouble(tf.getText());
				}
				else if(s.equals("realBottom")){
					mbg.realBottom = Double.parseDouble(tf.getText())*-1;
				}
				else if(s.equals("imagTop")){
					mbg.imagTop = Double.parseDouble(tf.getText());
				}
				else if(s.equals("imagBottom")){
					mbg.imagBottom = Double.parseDouble(tf.getText())*-1;
				}
				else if(s.equals("iterate")){
					mbg.iterate = Integer.parseInt(tf.getText());
				}
				repaint();
			}			
		}
		//this class takes a string of the text which is the name of the number it is attached to and the textfield connected to it
		//it sets the value of the number connected to the textfield to the number entered and calls repaint
		public boolean isNumeric(String str)  
		{  
			try{  
				double d = Double.parseDouble(str);  
			}  
			catch(NumberFormatException nfe){  
				return false;  
			}  
			return true;  
		}
		//a simple method just to test if a string is a number		
	}
}
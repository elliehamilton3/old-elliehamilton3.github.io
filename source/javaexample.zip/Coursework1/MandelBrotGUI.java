import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

import javax.swing.*;


@SuppressWarnings("serial")
public class MandelBrotGUI extends JPanel{
	JTextField clickTF;
	//the reference to the user selected point or if live updates are on the point the mouse is on
	private int x1, y1, x2, y2;
	private boolean dragging = false;
	private boolean upsideDown;
	//references to the mouse pressed and dragged points used for zooming and drawing the box
	//and booleans to help with the drawing of the box
	private double panelHeight, panelWidth;
	double realTop = 2.0, realBottom = -2.0, imagTop = 1.6, imagBottom = -1.6;
	//stores its own panel height and width and real and imaginary top and bottom of the axis 
	//the real and imaginary axis values are public so they can be accessed by the textfield on the main display
	FractalGUI frac = new FractalGUI(this);
	//a reference to the connected fractal gui and is constructed when the mandelbrot is and then is just updated
	//is stored here so that it can share information with the frame and the fractal gui	
	int iterate = 100;
	//stores the number of iterations the set should do, shared with the fractal gui and updated by the frame
	boolean updatesOn = true;
	//boolean used to turn the live julia set updates on or off, these can be left on to update the complex number hovered on in the set if not julia set
	int trapType = 0;
	//this int is used to set the orbit trap on display, default set to the normal mandelbrot visualisation 
	public void init(){
		setSize(500, 500);
		Dimension d = getSize();
		panelWidth = d.getWidth();
		panelHeight = d.getHeight();
		MandelBrotListener mbl = new MandelBrotListener();
		addMouseListener(mbl);
		addMouseMotionListener(mbl);
	}
	//it sets the size of the panel and the panel width and height and adds a mouse listener and mouse motion listener
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		panelWidth = getWidth();
		panelHeight = getHeight();
		if(trapType == 0){
			visualiseMSet(g);
		}
		else{
			visualiseMSetOrbital(g);
		}
		if(dragging){
			g.setColor(Color.RED);
			if (x2>x1){
				g.drawRect(x1, y1, x2-x1, y2-y1);
				upsideDown = false;
			}
			else{
				g.drawRect(x2, y2, x1-x2, y1-y2);
				upsideDown = true;
			}
		}
	}
	/*calls the super paint method calls the visualiseMSet method and 
	*uses the dragging boolean to decide whether to draw a rectangle using the points set by mouse pressed and mouse dragged
	*also sets if the rectangle is being drawn upside down and acts accordingly, red box outline does draw although takes a little while
	*/
	public Complex toComplexNum(int x, int y){
		double xInc = (realTop-realBottom)/panelWidth;
		double yInc = (imagTop-imagBottom)/panelHeight;
		double r = (x*xInc) + realBottom;
		double i = imagTop - (y*yInc);
		return new Complex(r, i);	
	}
	//this method turns x and y coordinates to a complex number which it returns
	public Complex fromString(String s){
		String num2 = s.trim();
		String[] s1 = num2.split(" ");
		double r = Double.parseDouble(s1[0]);
		String[] s2 = s1[2].split("i");
		double i = Double.parseDouble(s2[0]);
		return new Complex(r, i);
	}
	//this method takes a string and turns it into a complex number
	//used with the favourites combo box which returns the favourite selected as a string
    public BufferedImage getScreenShot(JPanel panel){
        BufferedImage bi = new BufferedImage(panel.getWidth(), panel.getHeight(), BufferedImage.TYPE_INT_ARGB);
        panel.paint(bi.getGraphics());
        return bi;
    }
    //takes a jpanel and returns a buffered image, used for saving the left panel fractal set images to a file
	public void visualiseMSet(Graphics g){
		for(int y = 0; y <= panelHeight; y++){
			for(int x = 0; x <= panelWidth; x++){
				Complex c = toComplexNum(x, y);
				Complex c2 = new Complex(c.getReal(), c.getImag());
				for(int i = 1; i < iterate; i++){
					c2 = (c2.square()).add(c);
					if(c2.modulus() < 2){
						g.setColor(Color.BLACK);
					}
					else if(c2.modulus() > 2){
						if(i<=20){
							g.setColor(new Color(150, 255-(i*8), 255-(i)));
							i=iterate;
						}
						else if(i<=50){
							g.setColor(new Color(0, 255-(i*4), 255-(i)));
							i=iterate;
						}
						else if (i<=100){
							g.setColor(new Color(0, 255-(i*2), 255-(i)));
							i=iterate;
						}
						else{
							g.setColor(Color.BLACK);
							i=iterate;
						}
					}
					g.fillRect(x, y, 1, 1);
				}
			}
		}
	}
	/*this is the method which calculates and visualises the mandelbrot set
	 * it loops through pixel by pixel and does the mandelbrot set calculation to see if or when it diverges
	 * it uses this iterations value to set the colour to plot the pixel
	 */
	public int getDistance(Complex c, Complex point)
	{        
		Complex c2 = c;
		double min = 1e20;
		for(int i=1; i<iterate ; i++)
		{
			c2 = (c2.square()).add(c);
			double cMagnitude = 0;
			if(trapType == 1){
				cMagnitude = Math.abs(Math.sin(c2.getReal()*c2.getReal()+c2.getImag()*c2.getImag())/Math.cos(c2.getReal()*c2.getReal()+c2.getImag()*c2.getImag()));
			}
			else if(trapType == 2){
				cMagnitude = Math.abs(Math.sin(c2.getReal())/Math.cos(c2.getImag()));
			}
			else if(trapType == 3){
				cMagnitude = Math.abs(Math.sin(c2.getReal()*c2.getReal())/Math.sin(c2.getImag()*c2.getImag()));
			}
			else if(trapType == 4){
				cMagnitude = Math.abs(Math.sin(c2.getReal()*c2.getReal())/Math.cos(c2.getImag()*c2.getImag()));
			}
			if(cMagnitude < min){
				min = cMagnitude;
			}
			else if(cMagnitude>1000000 || cMagnitude < -100000){
				i=iterate;
			}
		}		
		return (int)Math.round(min*1000);
	}
	/*this method does the mandelbrot calculation for the orbit traps and has a number of different ways to calculate the magnitude to create different looking orbit traps
	 * this is set by the combo box and the set trap method, it calculates the minimum distance and returns an int which is made into a larger number so that it can be used to set the colours
	 */
	public void visualiseMSetOrbital(Graphics g){
		for(int y = 0; y <= panelHeight; y++){
			for(int x = 0; x <= panelWidth; x++){
				Complex c = toComplexNum(x, y);
				int d = getDistance(c, new Complex(0, 0));	
				if(d<0){
					g.setColor(Color.WHITE);
				}
				else if(d<4){
					g.setColor(new Color(0, (d*50), 255));
				}
				else if (d<10){
					g.setColor(new Color(255-(d*5), 0, (d*5)));
				}
				else if (d<100){
					g.setColor(new Color(d*2, 0, 255-(d*2)));
				}
				else if (d<100){
					g.setColor(new Color(d*2, 0, 255-(d*2)));
				}
				else if (d<200){
					g.setColor(new Color(d, 0, 255-d));
				}
				else if (d<10000){
					g.setColor(new Color(80, 0, 80));
				}
				else{
					g.setColor(Color.WHITE);
				}
				g.fillRect(x, y, 1, 1);
			}
		}
	}
	/*this is the method which calculates and visualises the mandelbrot set
	 * it loops through pixel by pixel and does the mandelbrot set calculation and returns an minimum distance by the get distance method
	 * it uses this minimum value to set the colour to plot the pixel
	 */
	public void setTrap(String s){
		if(s.equals("Normal")){
			trapType = 0;
		}
		else if(s.equals("Orbit Trap A")){
			trapType = 1;
		}
		else if(s.equals("Orbit Trap B")){
			trapType = 2;
		}
		else if(s.equals("Orbit Trap C")){
			trapType = 3;
		}
		else if(s.equals("Orbit Trap D")){
			trapType = 4;
		}
		else{
			trapType = 0;
		}
	}
	//this method recieves a string from the listener attached to the combobox and uses it to set the trap type or if it is normal or for some reason not one of the slected then it sets it to 0 the normal mandelbrot
	class MandelBrotListener implements MouseListener, MouseMotionListener{
	    public void mousePressed(MouseEvent e){ 
	    	x1 = e.getX();
	    	y1 = e.getY();
	    	frac.updateSet(toComplexNum(x1, y1));
	    	clickTF.setText((frac.userSelected).toString());
	    }
	    //updates the fractal set with a complex number of the user selected point which is created from the x and y coords of the mouse pressed event
	    //updates the text field with a string of the complex number
	    public void mouseDragged(MouseEvent e){    
	    	dragging = true;
	    	x2 = e.getX();
	    	y2 = e.getY();	
	    	repaint();
	    }
	    //as soon as a dragging event is triggered the boolean dragging is set to true and the x and y coords of the event are stored 
	    //repaint is called to start drawing the box
	    public void mouseReleased(MouseEvent e){
	    	if(dragging){
		    	dragging = false;
		    	Complex c1 = toComplexNum(x1, y1);
		    	Complex c2 = toComplexNum(e.getX(), e.getY());
		    	if(!upsideDown){
			    	realTop = c2.getReal();
			    	realBottom = c1.getReal();
			    	imagTop = c1.getImag();
			    	imagBottom = c2.getImag();	
		    	}
		    	else {
			    	realTop = c1.getReal();
			    	realBottom = c2.getReal();
			    	imagTop = c2.getImag();
			    	imagBottom = c1.getImag();	
		    	}
		    	repaint();
	    	}    	
	    }
	    //as soon as the mouse is released and if dragging is true then it is set to false
	    //complex numbers are created from the mouse pressed and released events 
	    //if the box is being drawn upside down then it reverses the complex numbers so that the area in the box displays on the screen
	    public void mouseMoved(MouseEvent e){    
	    	if(frac.isJulia()&&updatesOn){
		    	clickTF.setText((frac.userSelected).toString());
		    	frac.updateSet(toComplexNum(e.getX(), e.getY()));
	    	}
	    	else if(updatesOn){
		    	clickTF.setText((frac.userSelected).toString());
	    	}
	    }
	    //if the set being displayed is the julia set and live updates are on then it sets the text and resets the user selected point
	    //otherwise it just updates the text, setting the complex number to that being hovered over on the complex plane
	    public void mouseEntered(MouseEvent e){ }
	    public void mouseExited(MouseEvent e){ }
	    public void mouseClicked(MouseEvent e){  }
	    // the empty shells for the unimplemented methods
	}
}
